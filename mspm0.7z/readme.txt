工具版本信息：
Application: KiCad x64 on x64

Version: 8.0.1, release build

Libraries:
	wxWidgets 3.2.4
	FreeType 2.12.1
	HarfBuzz 8.3.0
	FontConfig 2.14.2
	libcurl/8.5.0-DEV Schannel zlib/1.3

Platform: Windows 11 (构建 22631)，64位版, 64 bit, Little endian, wxMSW

Build Info:
	Date: Mar 15 2024 01:52:47
	wxWidgets: 3.2.4 (wchar_t,wx containers)
	Boost: 1.83.0
	OCC: 7.7.1
	Curl: 8.5.0-DEV
	ngspice: 42
	Compiler: Visual C++ 1936 without C++ ABI

文件结构：
readme.txt———————本文件
ibom.html————————交互式BOM表
mspm0.kicad_pcb——PCB文件
mspm0.kicad_prl——工程配置文件
mspm0.kicad_pro——KiCad工程文件
mspm0.kicad_sch——原理图文件
out/—————————————制造输出文件夹（请重新生成）